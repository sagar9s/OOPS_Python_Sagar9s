#OOPR-Assgn-5
class Vehicle:
    def __init__(self):
        self.__vehicle_cost=None
        self.__vehicle_type=None
        self.__vehicle_id=None
        self.__premium_amount=None

    def get_vehicle_cost(self):
        return self.__vehicle_cost


    def get_vehicle_type(self):
        return self.__vehicle_type


    def get_vehicle_id(self):
        return self.__vehicle_id


    def get_premium_amount(self):
        return self.__premium_amount


    def set_vehicle_cost(self, vehicle_cost):
        self.__vehicle_cost = vehicle_cost


    def set_vehicle_type(self, vehicle_type):
        self.__vehicle_type = vehicle_type


    def set_vehicle_id(self, vehicle_id):
        self.__vehicle_id = vehicle_id


    def set_premium_amount(self, premium_amount):
        self.__premium_amount = premium_amount

         

    def calculate_premium (self):
        str1="vehicle type is invalid"
        if self.__vehicle_type=="Two Wheeler":
            self.__premium_amount=self.__vehicle_cost-self.__vehicle_cost*0.98
            return self.__premium_amount
        elif self.__vehicle_type=="Four Wheeler":
            self.__premium_amount=self.__vehicle_cost-self.__vehicle_cost*0.94
            return self.__premium_amount
        else:
            return str1
    def display_vehicle_details(self):
        return self.__vehicle_type,self.__vehicle_cost
       
    
v=Vehicle()
v.set_vehicle_cost(10500)
v.set_vehicle_type("Two Wheeler")
v.calculate_premium()