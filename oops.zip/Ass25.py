#OOPR-Assgn-25

class FruitInfo:
    
    __fruit_name_list=["Apple","Guava","Orange","Grape"," Sweet Lime"]
    __fruit_price_list=[200,80,70,110,60]
    
    @staticmethod
    def get_fruit_name_list():
        return FruitInfo.__fruit_name_list

    @staticmethod
    def get_fruit_price_list():
        return FruitInfo.__fruit_price_list

    
    
    @staticmethod
    def get_fruit_price(fruit_name):
        if fruit_name in FruitInfo.__fruit_name_list:
            return FruitInfo.__fruit_price_list[FruitInfo.__fruit_name_list.index(fruit_name)]
        else:
            return -1
    
class Purchase:
    __counter=101
    def __init__(self,customer,fruit_name,quantity):
        self.__customer=customer
        self.__fruit_name=fruit_name
        self.__quantity=quantity
        self.__purchase_id=None

    def get_customer(self):
        return self.__customer


    def get_quantity(self):
        return self.__quantity


    def get_purchase_id(self):
        return self.__purchase_id

    def calculate_price(self):
        price=0
        str1="P"
        self.__purchase_id=str1+str(Purchase.__counter)
        Purchase.__counter+=1
        fruit_name_list=list(FruitInfo.get_fruit_name_list())
        fruit_price_list=list(FruitInfo.get_fruit_price_list())
        if self.__fruit_name in fruit_name_list:
            price+=FruitInfo.get_fruit_price(self.__fruit_name)*self.__quantity
            if fruit_price_list[fruit_name_list.index(self.__fruit_name)]==max(fruit_price_list) and self.__quantity>1:
                price*=0.98
            if fruit_price_list[fruit_name_list.index(self.__fruit_name)]==min(fruit_price_list) and self.__quantity>=5:
                price*=0.95
            if self.__customer.get_cust_type().lower()=="wholesale":
                price*=0.9
            return price
        else:
            return -1

class Customer:
    def __init__(self,customer_name,cust_type):
        self.__customer_name=customer_name
        self.__cust_type=cust_type

    def get_customer_name(self):
        return self.__customer_name


    def get_cust_type(self):
        return self.__cust_type

    
        
