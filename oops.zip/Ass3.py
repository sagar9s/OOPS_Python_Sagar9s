#OOPR-Assgn-3

class Customer:
    def __init__(self,customer_name="Sagar",bill_amount=1000):
        self.customer_name=customer_name
        self.bill_amount=bill_amount
        

    def purchases (self):
        self.bill_amount=self.bill_amount*0.95
    def pays_bill(self,amount):
        #amount=self.bill_amount*0.95
        return str(self.customer_name)+" pays bill amount of Rs."+str(amount)
obj1=Customer()
obj1.purchases()
obj1.pays_bill(obj1.bill_amount)

    