#OOPR-Assgn-24
class Apparel:
    counter=100
    def __init__(self, price,item_type):
        self.__price = price
        self.__item_type = item_type
        Apparel.counter+=1
        self.__item_id=self.__item_type[0]+str(Apparel.counter)

    def get_price(self):
        return self.__price


    def get_item_type(self):
        return self.__item_type


    def get_item_id(self):
        return self.__item_id


    def set_price(self, price):
        self.__price = price
    
    def calculate_price(self):
        self.__price+=0.05*self.__price
        

class Cotton(Apparel):

    def __init__(self, price,discount):
        super().__init__(price, "Cotton")
        
        self.__discount = discount
        
    
    def calculate_price(self):
        super().calculate_price()
        price=self.get_price()
        discount=(self.__discount*price)/100
        price=price-discount
        price+=price*0.05
        self.set_price(price)
        
        
        
    def get_discount(self):
        return self.__discount
        
class Silk(Apparel):
    
    def __init__(self,price):
        super().__init__(price, "Silk")
        
        
        self.__points=None
    
    def get_points(self):
        return self.__points
    
    def calculate_price(self):
        super().calculate_price()
        price=self.get_price()
        if price>10000:
            self.__points=10
        else:
            self.__points=3
        
        price=price*1.1
        self.set_price(price) 
        
s1=Silk(10000)
s1.calculate_price()
print(s1.get_price())        
c1=Cotton(12000,10)
c1.calculate_price()
print(c1.get_price())        
    

    