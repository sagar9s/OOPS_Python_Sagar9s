#OOPR-Assgn-18
class Customer:
    def __init__(self,customer_name):
        self.__customer_name=customer_name
        self.__payment_status=None
    def get_customer_name(self):
        return self.__customer_name


    def get_payment_status(self):
        return self.__payment_status

    def pays_bill(self,bill):
        bill=Bill()
        self.__payment_status="Paid"
        return self.__customer_name,bill.get_bill_id(),bill.get_bill_amount()
    
class Bill:
    counter=1000
    def __init__(self):
        Bill.counter+=1
        self.__bill_id=Bill.counter
        self.__bill_amount=0

    def get_bill_id(self):
        return self.__bill_id


    def get_bill_amount(self):
        return self.__bill_amount

    def generate_bill_amount(self,item_quantity,items):
        #item_quantity={100:2,101:3,102:4}
        #items=['A','B','C']
        bill1=0
        str1="B"
        self.__bill_id=str1+str(self.__bill_id)
        for k,v in item_quantity.items():
            for item in items:
                if item.get_item_id().upper()==k.upper():
                
                    bill1+=v*item.get_price_per_quantity()
        self.__bill_amount+=bill1
    
class Item:

    def __init__(self,item_id,description,price_per_quantity):
        self.__item_id=item_id
        self.__description=description
        self.__price_per_quantity=price_per_quantity

    def get_item_id(self):
        return self.__item_id


    def get_description(self):
        return self.__description


    def get_price_per_quantity(self):
        return self.__price_per_quantity

    