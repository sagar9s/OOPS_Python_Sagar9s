#OOPR-Exer-7
class Ticket:
    counter=0
    def __init__(self,passenger_name,source,destination):
        self.__passenger_name=passenger_name
        self.__source=source
        self.__destination=destination
        self.__ticket_id=None

    def get_passenger_name(self):
        return self.__passenger_name


    def get_source(self):
        return self.__source


    def get_destination(self):
        return self.__destination


    def get_ticket_id(self):
        return self.__ticket_id
    
    def generate_ticket(self):
        str1=""
        str1+=self.__source[0]+self.__destination[0]
        if self.validate_source_destination():
            Ticket.counter+=1
            if Ticket.counter>=10:
                self.__ticket_id=str1+str(Ticket.counter)
            else:
                self.__ticket_id=str1+"0"+str(Ticket.counter)
        else:
            self.__ticket_id=None
        return self.__ticket_id
    
    def validate_source_destination(self):
        if self.__source.lower()=="delhi" and self.__destination.lower() in ['mumbai','chennai','pune','kolkata']:
            return True
        else:
            return False