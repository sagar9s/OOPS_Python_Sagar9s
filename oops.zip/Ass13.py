#OOPR-Assgn-13
class Classroom:
    classroom_list=[]
        
    @staticmethod
    def search_classroom(class_room):
        str1="Found" 
        if class_room.upper() in Classroom.classroom_list:
            return str1
        else:
            return -1